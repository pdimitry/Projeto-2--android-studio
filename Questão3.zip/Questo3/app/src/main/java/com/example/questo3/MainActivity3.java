package com.example.questo3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity3 extends AppCompatActivity {

    private TextView txtMensagem;
    private Button btnVoltar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        txtMensagem = findViewById(R.id.txtMensagem);
        btnVoltar = findViewById(R.id.btnVoltar);

        String nomeCliente = getIntent().getStringExtra("nomeCliente");
        txtMensagem.setText("Bem-vindo, " + nomeCliente + "! Seu cadastro foi concluído.");

        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity3.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }
}