package com.example.questo5;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity {

    RadioGroup groupTamanho, groupPagamento;
    Button btnFinalizar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        groupTamanho = findViewById(R.id.groupTamanho);
        groupPagamento = findViewById(R.id.groupPagamento);
        btnFinalizar = findViewById(R.id.btnFinalizar);

        String pizzas = getIntent().getStringExtra("pizzas");

        btnFinalizar.setOnClickListener(view -> {
            int tamanhoId = groupTamanho.getCheckedRadioButtonId();
            int pagamentoId = groupPagamento.getCheckedRadioButtonId();

            if (tamanhoId == -1 || pagamentoId == -1) {
                Toast.makeText(this, "Selecione o tamanho e o pagamento", Toast.LENGTH_SHORT).show();
                return;
            }

            RadioButton rbTamanho = findViewById(tamanhoId);
            RadioButton rbPagamento = findViewById(pagamentoId);

            String tamanho = rbTamanho.getText().toString();
            String pagamento = rbPagamento.getText().toString();

            int valor = 0;
            if (tamanho.contains("Pequena")) valor = 25;
            else if (tamanho.contains("Média")) valor = 35;
            else if (tamanho.contains("Grande")) valor = 45;

            Intent intent = new Intent(MainActivity2.this, MainActivity3.class);
            intent.putExtra("pizzas", pizzas);
            intent.putExtra("tamanho", tamanho);
            intent.putExtra("pagamento", pagamento);
            intent.putExtra("valor", valor);
            startActivity(intent);
        });
    }
}