package com.example.questo5;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity3 extends AppCompatActivity {

    TextView txtResumoFinal;
    Button btnNovo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        txtResumoFinal = findViewById(R.id.txtResumoFinal);
        btnNovo = findViewById(R.id.btnNovo);

        String pizzas = getIntent().getStringExtra("pizzas");
        String tamanho = getIntent().getStringExtra("tamanho");
        String pagamento = getIntent().getStringExtra("pagamento");
        int valor = getIntent().getIntExtra("valor", 0);

        String resumo = "Pizzas: " + pizzas +
                "Tamanho: " + tamanho + "\n" +
                "Pagamento: " + pagamento + "\n" +
                "Total: R$" + valor;

        txtResumoFinal.setText(resumo);

        btnNovo.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity3.this, MainActivity.class);
            startActivity(intent);
            finish();
        });
    }
}