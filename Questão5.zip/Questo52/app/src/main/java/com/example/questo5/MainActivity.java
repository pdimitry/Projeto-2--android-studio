package com.example.questo5;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    CheckBox chkCalabresa, chkMarguerita, chkPortuguesa;
    Button btnAvancar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        chkCalabresa = findViewById(R.id.chkCalabresa);
        chkMarguerita = findViewById(R.id.chkMarguerita);
        chkPortuguesa = findViewById(R.id.chkPortuguesa);
        btnAvancar = findViewById(R.id.btnAvancar);

        btnAvancar.setOnClickListener(view -> {
            StringBuilder pizzasSelecionadas = new StringBuilder();

            if (chkCalabresa.isChecked()) pizzasSelecionadas.append("Calabresa\n");
            if (chkMarguerita.isChecked()) pizzasSelecionadas.append("Marguerita\n");
            if (chkPortuguesa.isChecked()) pizzasSelecionadas.append("Portuguesa\n");

            if (pizzasSelecionadas.length() == 0) {
                Toast.makeText(this, "Selecione pelo menos uma pizza", Toast.LENGTH_SHORT).show();
            } else {
                Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                intent.putExtra("pizzas", pizzasSelecionadas.toString());
                startActivity(intent);
            }
        });
    }
}