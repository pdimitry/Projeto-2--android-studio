package com.example.questo4;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.textfield.TextInputEditText;

public class MainActivity2 extends AppCompatActivity {

    TextInputEditText edtNomeCliente;
    RadioGroup groupLanches;
    Button btnConfirmar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        edtNomeCliente = findViewById(R.id.edtNomeCliente);
        groupLanches = findViewById(R.id.groupLanches);
        btnConfirmar = findViewById(R.id.btnConfirmar);

        btnConfirmar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nome = edtNomeCliente.getText().toString().trim();

                int selectedId = groupLanches.getCheckedRadioButtonId();
                if (selectedId == -1 || nome.isEmpty()) {
                    Toast.makeText(MainActivity2.this, "Preencha o nome e selecione um lanche!", Toast.LENGTH_SHORT).show();
                    return;
                }

                RadioButton selectedLanche = findViewById(selectedId);
                String lanche = selectedLanche.getText().toString();

                Intent intent = new Intent(MainActivity2.this, MainActivity3.class);
                intent.putExtra("nome", nome);
                intent.putExtra("lanche", lanche);
                startActivity(intent);
            }
        });
    }
}