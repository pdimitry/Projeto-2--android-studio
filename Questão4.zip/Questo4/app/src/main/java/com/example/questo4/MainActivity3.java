package com.example.questo4;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        // Recebendo os dados da Intent
        String nomeCliente = getIntent().getStringExtra("nome");
        String lancheEscolhido = getIntent().getStringExtra("lanche");

        // Acessando o TextView onde o resumo será exibido
        TextView txtResumo = findViewById(R.id.txtResumo);

        // Exibindo o resumo do pedido, caso os dados tenham sido passados corretamente
        if (nomeCliente != null && lancheEscolhido != null) {
            txtResumo.setText("Resumo:\n" + nomeCliente + "\n" + lancheEscolhido);
        } else {
            // Caso algum dado não tenha sido passado corretamente
            Toast.makeText(this, "Erro ao carregar o pedido", Toast.LENGTH_SHORT).show();
        }

        // Acessando o botão "Novo Pedido"
        Button btnNovoPedido = findViewById(R.id.btnNovoPedido);

        // Configurando o OnClickListener para o botão
        btnNovoPedido.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Retornando à MainActivity
                Intent intent = new Intent(MainActivity3.this, MainActivity.class);
                startActivity(intent);
                finish(); // Finaliza a MainActivity3 para que o usuário não volte para ela
            }
        });
    }
}
