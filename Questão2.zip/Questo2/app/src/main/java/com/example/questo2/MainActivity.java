package com.example.questo2;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText edtSalario;
    private RadioGroup rgOpcoes;
    private RadioButton rb40, rb45, rb50;
    private Button btnCalcular;
    private TextView txtResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtSalario = findViewById(R.id.edtSalario);
        rgOpcoes = findViewById(R.id.rgOpcoes);
        rb40 = findViewById(R.id.rb40);
        rb45 = findViewById(R.id.rb45);
        rb50 = findViewById(R.id.rb50);
        btnCalcular = findViewById(R.id.btnCalcular);
        txtResultado = findViewById(R.id.txtResultado);

        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calcularNovoSalario();
            }
        });
    }

    private void calcularNovoSalario() {
        String salarioTexto = edtSalario.getText().toString();

        if (salarioTexto.isEmpty()) {
            txtResultado.setText("Por favor, insira um salário.");
            return;
        }

        double salario = Double.parseDouble(salarioTexto);
        double aumento = 0;

        if (rb40.isChecked()) {
            aumento = 0.40;
        } else if (rb45.isChecked()) {
            aumento = 0.45;
        } else if (rb50.isChecked()) {
            aumento = 0.50;
        } else {
            txtResultado.setText("Selecione um percentual de aumento.");
            return;
        }

        double novoSalario = salario + (salario * aumento);
        txtResultado.setText(String.format("Novo Salário: R$ %.2f", novoSalario));
    }
}